package com.lasalle.met.shoplist.Controller;

/**
 * Created by JORDI on 10/01/2018.
 */

public class AddActivity {
}
